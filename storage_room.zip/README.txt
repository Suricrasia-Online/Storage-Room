### storage room - blackle / suricrasia online ###
         party like it's 1995 (bytes)

storage room is a 2k exegfx for 64-bit linux, specifically targeting Ubuntu 18.10

Packages needed (all of these are installed by default):

libglib2.0-0
libgtk-3-0
and whatever package gives you libgl (depends on graphics card)

Two versions of the demo are distributed. storage_room is the size optimized, packed version. storage_room_unpacked is the unpacked version that is lacking.

This exegfx will not render on resolutions lower than 1920x1080. What it produces at higher resolutions is undefined.

Exit at any moment with "esc" or with your window manager's "close window" key combo.

You can set the number of samples with the environment variable SAMPLES:

env SAMPLES=300 ./storage_room

The default number of samples is 300.

BLACK LIVES MATTER - REDISTRIBUTE YOUR OWN WEALTH - ABOLISH THE POLICE
